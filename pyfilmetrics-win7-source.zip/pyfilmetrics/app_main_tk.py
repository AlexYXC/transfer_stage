"""Entry point for the Tkinter (Windows-7-friendly) build of pyFILMeasure."""
import multiprocessing

from filmeas.app.gui_tk import main

if __name__ == "__main__":
    multiprocessing.freeze_support()
    raise SystemExit(main())
